//
//  mklfs.h
//  
//
//  Created by Dennis Xu on 10/18/13.
//
//

#ifndef ____mklfs__
#define ____mklfs__

#include <iostream>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "lld.h"
#include "log.h"
#include "flash.h"

#endif /* defined(____mklfs__) */
